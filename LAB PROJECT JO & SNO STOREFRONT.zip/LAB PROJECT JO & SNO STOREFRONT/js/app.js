// Product Catalog State
const products = [
    {
        id: 'NFT-101',
        name: 'Heart Eyez #4042',
        category: 'NFT',
        desc: '1-of-1 digital avatar stored on Ethereum with full commercial IP rights.',
        cost: 50.00,
        image: 'heartssmile.avif'
    },
    {
        id: 'NFT-102',
        name: 'CryptoMan on Solana',
        category: 'NFT',
        desc: 'Utility NFT pass granting VIP access to upcoming DeFi launches and DAO governance.',
        cost: 20.00,
        image: 'cryman.avif'
    },
    {
        id: 'NFT-103',
        name: 'MetaMan',
        category: 'NFT',
        desc: 'MetaMan collection on the POLYGON blockchain.',
        cost: 45.00,
        image: 'cryptoman.avif'
    },
    {
        id: 'NFT-104',
        name: 'Flower Flow - Limited Edition',
        category: 'NFT',
        desc: 'from the Flower collection by ACKnighten.',
        cost: 80.00,
        image: 'flower.avif'
    },
    {
        id: 'NFT-105',
        name: 'tale of 2 Kingz #88',
        category: 'NFT',
        desc: 'Virtual land plot in Sandbox Metaverse core district with development SDK access.',
        cost: 50.00,
        image: 'taleof2tails.htm'
    },
    {
        id: 'DAP-201',
        name: 'Uniswap Liquidity Bot Dapp',
        category: 'Dapp',
        desc: 'Automated yield management and rebalancing application for Uniswap V3 pools.',
        cost: 50.00,
        image: 'whatuC.avif'
    },
    {
        id: 'DAP-202',
        name: 'Aave Vault Manager Dapp',
        category: 'Dapp',
        desc: 'Smart contract suite for auto-collateralization and debt health management on Aave.',
        cost: 90.00,
        image: 'iam.avif'
    },
    {
        id: 'DAP-203',
        name: 'USB Mining/Trading Expert Advisor',
        category: 'Dapp',
        desc: 'mines crypto to fund trading acount.',
        cost: 35.00,
        image: 'flower.avif'
    },
    {
        id: 'DAP-204',
        name: 'USB Cold Wallet with ESP32-cam',
        category: 'Dapp',
        desc: 'USB Crypto offline storage wallet with QR reader.',
        cost: 89.00,
        image: 'heartssmile.avif'
    },
    {
        id: 'TOK-301',
        name: 'AYA Token Poly',
        category: 'Crypto Token',
        desc: 'Polygon best trading token.',
        cost: 6.00,
        image: 'AYA Token yellow GREEN.png'
    },
    {
        id: 'TOK-302',
        name: 'JO & SNO Network Token',
        category: 'Crypto Token',
        desc: 'JSN is on the binance blockchain. Staking is avaible on select Dexs.',
        cost: 31.00,
        image: 'JSN Solana.jpg'
    },
    {
        id: 'TOK-303',
        name: 'AYA Token',
        category: 'Crypto Token',
        desc: 'Solana is home to this token. Currently expanding CEXs.',
        cost: 15.00,
        image: 'AYAtokenBLU.jpg'
    }
];

const cart = {};
products.forEach(p => { cart[p.id] = 0; });

let currentCategory = 'All';
let searchQuery = '';

function setCategory(category) {
    currentCategory = category;
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.category === category);
    });
    renderCatalog();
}

function handleSearch(query) {
    searchQuery = query.toLowerCase().trim();
    renderCatalog();
}

function showView(viewName) {
    const catalogView = document.getElementById('catalog-view');
    const cartView = document.getElementById('cart-view');
iam.avif
    if (viewName === 'cart') {
        catalogView.classList.add('hidden');
        cartView.classList.remove('hidden');
        renderCart();
    } else {
        cartView.classList.add('hidden');
        catalogView.classList.remove('hidden');
        renderCatalog();
    }
}

function addProduct(id) {
    cart[id]++;
    updateUI();
}

function decrementProduct(id) {
    if (cart[id] > 0) {
        cart[id]--;
    }
    updateUI();
}

function removeProduct(id) {
    cart[id] = 0;
    updateUI();
}

function checkout() {
    for (let id in cart) {
        cart[id] = 0;
    }
    const alertBox = document.getElementById('checkout-alert');
    alertBox.style.display = 'block';
    setTimeout(() => { alertBox.style.display = 'none'; }, 4000);
    showView('catalog');
}

function getTotalItemCount() {
    return Object.values(cart).reduce((sum, qty) => sum + qty, 0);
}

// Robust Live Crypto Prices Fetcher using Coinbase Public API
async function fetchCryptoPrices() {
    const cryptos = [
        { id: 'ticker-bitcoin', symbol: 'BTC-USD' },
        { id: 'ticker-ethereum', symbol: 'ETH-USD' },
        { id: 'ticker-solana', symbol: 'SOL-USD' },
        { id: 'ticker-xrp', symbol: 'XRP-USD' }
    ];

    for (const crypto of cryptos) {
        try {
            const response = await fetch(`https://api.coinbase.com/v2/prices/${crypto.symbol}/spot`);
            const result = await response.json();
            if (result && result.data && result.data.amount) {
                const priceNum = parseFloat(result.data.amount);
                const formatted = priceNum.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
                const targetEl = document.querySelector(`#${crypto.id} .crypto-price`);
                if (targetEl) targetEl.textContent = formatted;
            }
        } catch (error) {
            console.warn(`Could not load price for ${crypto.symbol}:`, error);
        }
    }
}

function renderCatalog() {
    const grid = document.getElementById('product-grid');
    grid.innerHTML = '';

    const filteredProducts = products.filter(p => {
        const matchesCategory = (currentCategory === 'All') || (p.category === currentCategory);
        const matchesSearch = p.name.toLowerCase().includes(searchQuery) ||
                              p.desc.toLowerCase().includes(searchQuery) ||
                              p.id.toLowerCase().includes(searchQuery);
        return matchesCategory && matchesSearch;
    });

    if (filteredProducts.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #94a3b8;">
                No products found matching your active filter and search terms.
            </div>
        `;
        document.getElementById('nav-cart-count').textContent = getTotalItemCount();
        return;
    }

    filteredProducts.forEach(p => {
        const badgeClass = `badge-${p.category.toLowerCase().replace(/\s+/g, '')}`;
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div>
                <img src="${p.image}" alt="${p.name}">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; margin-bottom: 8px;">
                    <h3 style="margin: 0; font-size: 16px;">${p.name}</h3>
                    <span class="badge ${badgeClass}">${p.category}</span>
                </div>
                <p style="font-size: 12px; color: #94a3b8; margin: 0 0 8px 0;"><strong>Product ID:</strong> ${p.id}</p>
                <p style="font-size: 14px; margin: 0 0 12px 0; color: #cbd5e1;">${p.desc}</p>
            </div>
            <div>
                <p style="margin: 4px 0;"><strong>Cost:</strong> $${p.cost.toFixed(2)}</p>
                <p style="margin: 4px 0 12px 0;"><strong>In Cart:</strong> ${cart[p.id]}</p>
                
                <div class="actions">
                    <button class="btn btn-qty" onclick="decrementProduct('${p.id}')">-</button>
                    <button class="btn btn-qty" onclick="addProduct('${p.id}')">+</button>
                    <button class="btn" onclick="addProduct('${p.id}')">Add to Cart</button>
                    <button class="btn btn-danger" onclick="removeProduct('${p.id}')">Remove</button>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });

    document.getElementById('nav-cart-count').textContent = getTotalItemCount();
}

function renderCart() {
    const tbody = document.getElementById('cart-table-body');
    const summaryBox = document.getElementById('cart-summary');
    tbody.innerHTML = '';

    let subtotal = 0;
    let hasItems = false;

    products.forEach(p => {
        const qty = cart[p.id];
        if (qty > 0) {
            hasItems = true;
            const lineTotal = p.cost * qty;
            subtotal += lineTotal;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${p.id}</td>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td>$${p.cost.toFixed(2)}</td>
                <td>${qty}</td>
                <td>$${lineTotal.toFixed(2)}</td>
            `;
            tbody.appendChild(tr);
        }
    });

    if (!hasItems) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align:center; padding: 30px; color: #94a3b8;">
                    Your cart is currently empty.
                </td>
            </tr>
        `;
        summaryBox.classList.add('hidden');
    } else {
        const tax = subtotal * 0.05;
        const shipping = subtotal * 0.10;
        const orderTotal = subtotal + tax + shipping;

        document.getElementById('subtotal-val').textContent = subtotal.toFixed(2);
        document.getElementById('tax-val').textContent = tax.toFixed(2);
        document.getElementById('shipping-val').textContent = shipping.toFixed(2);
        document.getElementById('total-val').textContent = orderTotal.toFixed(2);

        summaryBox.classList.remove('hidden');
    }
}

function updateUI() {
    renderCatalog();
    renderCart();
}

renderCatalog();
fetchCryptoPrices();
setInterval(fetchCryptoPrices, 30000);