<!DOCTYPE html>
<html lang="en">
<head>
<title>YOO Famo</title> 
	<style>
		h1 {
			text-align: center;
			padding-top: 45vh;
	</style
</head>
<body>
<?php
echo "<h1 style='text-align:center;padding-top:48vh;'>";
echo "What Up Famo!";
?>
"</h1>";
<script> 
	console.log('you go boi')
</script>
</body>
</html>

