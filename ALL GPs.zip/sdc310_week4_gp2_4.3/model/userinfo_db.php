<?php
require_once('database.php');
 //Connect to Database  
 function get_all_users()
 {
     
 //Query for all users
 $conn = get_db_conn();
 $query = "SELECT * FROM userinfo";
 $result = mysqli_query($conn, $query);
return $result;
}
?>
