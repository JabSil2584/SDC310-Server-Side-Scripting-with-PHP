<?php
    require_once('../model/database.php');

    //controller function to get connect status
    function get_db_conn()
    {
        if (get_db_conn())
        {
            return "Connection successful";
        }
        else
        {
            return "Connection failed";
        }
    }
    ?>