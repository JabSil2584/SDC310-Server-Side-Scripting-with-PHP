<?php
// Controller: Links the View and the Model

require_once 'model.php';

$conn = get_db_connection();

// Establish variables to support add/edit/delete
$userNo = -1;
$firstName = "";
$lastName = "";
$email = "";
$favNum = 0;

// Variables to determine the type of operation
$add = false;
$edit = false;
$update = false;
$delete = false;

if (isset($_POST['user_no'])) {
    $userNo = $_POST['user_no'];
    $add = isset($_POST['add']);
    $update = isset($_POST['update']);
    $edit = isset($_POST['edit']);
    $delete = isset($_POST['delete']);
}

if ($add) {
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $email = $_POST['email'];
    $favNum = $_POST['fav_num'];

    add_user($conn, $firstName, $lastName, $email, $favNum);

    // Clear the fields
    $userNo = -1;
    $firstName = "";
    $lastName = "";
    $email = "";
    $favNum = "";
}
else if ($edit) {
    $userInfo = get_user_by_id($conn, $userNo);
    
    if ($userInfo) {
        $firstName = $userInfo['FirstName'];
        $lastName = $userInfo['LastName'];
        $email = $userInfo['EMail'];
        $favNum = $userInfo['FavoriteNum'];
    }
}
else if ($update) {
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $email = $_POST['email'];
    $favNum = $_POST['fav_num'];

    update_user($conn, $userNo, $firstName, $lastName, $email, $favNum);

    // Clear the fields
    $userNo = "";
    $firstName = "";
    $lastName = "";
    $email = "";
    $favNum = "";
}
else if ($delete) {
    delete_user($conn, $userNo);
    $userNo = -1;
}

// Query for all users to pass to the view
$result = get_all_users($conn);

// Load the View
include 'view.php';
?>