<?php
// Model: Database access and query information

function get_db_connection() {
    $hostname = "localhost";
    $username = "ecpi_user";
    $password = "Password1";
    $dbname = "sdc310_wk3gp";
    $conn = mysqli_connect($hostname, $username, $password, $dbname);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}

function get_all_users($conn) {
    $query = "SELECT * FROM userinfo";
    return mysqli_query($conn, $query);
}

function get_user_by_id($conn, $userNo) {
    $selQuery = "SELECT * FROM userinfo WHERE UserNo = $userNo";
    $result = mysqli_query($conn, $selQuery);
    return mysqli_fetch_assoc($result);
}

function add_user($conn, $firstName, $lastName, $email, $favNum) {
    $addQuery = "INSERT INTO userinfo (FirstName, LastName, EMail, FavoriteNum)
                VALUES ('$firstName', '$lastName', '$email', '$favNum')";
    return mysqli_query($conn, $addQuery);
}

function update_user($conn, $userNo, $firstName, $lastName, $email, $favNum) {
    $updQuery = "UPDATE userinfo SET
                FirstName = '$firstName', LastName = '$lastName', 
                EMail = '$email', FavoriteNum = $favNum 
                WHERE UserNo = $userNo";
    return mysqli_query($conn, $updQuery);
}

function delete_user($conn, $userNo) {
    $delQuery = "DELETE FROM userinfo WHERE UserNo = $userNo";
    return mysqli_query($conn, $delQuery);
}
?>