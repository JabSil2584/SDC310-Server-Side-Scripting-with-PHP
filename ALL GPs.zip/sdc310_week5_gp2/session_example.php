<?php
    session_start();

    if (!isset($_SESSION['user'])) {
        $_SESSION['user'] = "No Entry";
    }

    if (isset($_POST['user'])) {
        $_SESSION['user'] = $_POST['user'];
    }
    ?>
    <html>
        <head>
            <title>Week5 GP2 - JaBoris Silas</title>
        </head>
        <body>
            <h2>Store a Name in the Session</h2>
            <form method="POST">
                <h3>Name: <input type="text" name="user"
                    value="<?php echo $_SESSION['user']; ?>"/></h3>
                <input type="submit" value="Submit"/>
            </form>
            <br>
            <a href="session_value.php">Show Session Value Page</a>
</body>
    </html>