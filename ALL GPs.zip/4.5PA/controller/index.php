<?php
require_once('../model/database.php');
require_once('../model/product_db.php');

$action = filter_input(INPUT_POST, 'action');
if ($action === NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action === NULL) {
        $action = 'display_products';
    }
}

if ($action === 'display_products') {
    // Fetch products from the database model
    $products = get_products();
    
    // Include the view to display products
    include('../view/display_products.php');
}
?>