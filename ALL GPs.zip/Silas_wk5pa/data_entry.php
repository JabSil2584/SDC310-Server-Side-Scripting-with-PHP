<?php
// Start session for storing the date of birth
session_start();

// Handle form submission and store data in Cookie and Session
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name'])) {
        $name = trim($_POST['name']);
        // Store name in a cookie for 30 days
        setcookie('user_name', $name, time() + (86400 * 30), "/");
        $_COOKIE['user_name'] = $name; // Make available immediately in current request
    }

    if (isset($_POST['dob'])) {
        $dob = trim($_POST['dob']);
        // Store date of birth in session
        $_SESSION['dob'] = $dob;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Name Wk 5 Performance Assessment</title>
</head>
<body>
    <h3>Store your name in a cookie and birthdate in the Session</h3>
    <form method="POST">
        <label for="name"><strong>Name:</strong></label>
        <input type="text" name="name" value="<?php echo isset($_COOKIE['user_name']) ? htmlspecialchars($_COOKIE['user_name']) : ''; ?>"><br><br>
        
        <label for="dob"><strong>Date of Birth:</strong></label>
        <input type="text" name="dob" value="<?php echo isset($_SESSION['dob']) ? htmlspecialchars($_SESSION['dob']) : ''; ?>"><br><br>
        
        <input type="submit" value="Submit">
    </form>
    <br>
    <a href="data_display.php">Show Data Display Page</a>
</body>
</html>