<?php
// Connect to Database
$hostname = "localhost";
$username = "ecpi_user";
$password = "Password1";
$dbname = "sdc310_wk3pa";
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Establish variables to support add/edit/delete
$id = -1;
$name = "";
$dob = "";
$favColor = "";
$favPlace = "";
$nickname = "";

// Variables to determine the type of operation
$add = false;
$edit = false;
$update = false;
$delete = false;

if (isset($_POST['person_id'])) {
    $id = $_POST['person_id'];
    $add = isset($_POST['add']);
    $update = isset($_POST['update']);
    $edit = isset($_POST['edit']);
    $delete = isset($_POST['delete']);
}

if ($add) {
    // Need to add new personal information
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $favColor = $_POST['fav_color'];
    $favPlace = $_POST['fav_place'];
    $nickname = $_POST['nickname'];

    $addQuery = "INSERT INTO personal_info (Name, DOB, FavColor, FavPlace, Nickname) 
                 VALUES ('$name', '$dob', '$favColor', '$favPlace', '$nickname')";
    mysqli_query($conn, $addQuery);

    // Clear the fields
    $id = -1;
    $name = "";
    $dob = "";
    $favColor = "";
    $favPlace = "";
    $nickname = "";
}
else if ($edit) {
    // Get the personal information for editing
    $selQuery = "SELECT * FROM personal_info WHERE id = $id";
    $result = mysqli_query($conn, $selQuery);
    $rowInfo = mysqli_fetch_assoc($result);

    // Fill in the values to allow for edit
    $name = $rowInfo['Name'];
    $dob = $rowInfo['DOB'];
    $favColor = $rowInfo['FavColor'];
    $favPlace = $rowInfo['FavPlace'];
    $nickname = $rowInfo['Nickname'];
}
else if ($update) {
    // Updated values submitted
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $favColor = $_POST['fav_color'];
    $favPlace = $_POST['fav_place'];
    $nickname = $_POST['nickname'];

    $updQuery = "UPDATE personal_info SET 
                 Name = '$name', DOB = '$dob', FavColor = '$favColor', 
                 FavPlace = '$favPlace', Nickname = '$nickname' 
                 WHERE id = $id";
    mysqli_query($conn, $updQuery);

    // Clear the fields
    $id = -1;
    $name = "";
    $dob = "";
    $favColor = "";
    $favPlace = "";
    $nickname = "";
}
else if ($delete) {
    // Need to delete the selected record
    $delQuery = "DELETE FROM personal_info WHERE id = $id";
    mysqli_query($conn, $delQuery);
    $id = -1;
}

// Query for all records
$query = "SELECT * FROM personal_info";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Jaboris Silas Wk 3 Performance Assessment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        table {
            border-spacing: 5px;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: lightskyblue;
        }
        tr:nth-child(even) {
            background-color: whitesmoke;
        }
        tr:nth-child(odd) {
            background-color: lightgray;
        }
        form {
            margin-top: 20px;
        }
        input[type="text"], input[type="date"] {
            padding: 6px;
            margin: 5px 0;
            width: 250px;
        }
    </style>
</head>
<body>
    <h2>Stored Personal Information</h2>
    <table>
        <tr style="font-size:large;">
            <th>ID</th>
            <th>Name</th>
            <th>Date of Birth</th>
            <th>Favorite Color</th>
            <th>Favorite Place To Visit</th>
            <th>Nickname</th>
            <th></th>
            <th></th>
        </tr>

        <?php while($row = mysqli_fetch_array($result)): ?>
        <tr>
            <td><?php echo $row["id"]; ?></td>
            <td><?php echo $row["Name"]; ?></td>
            <td><?php echo $row["DOB"]; ?></td>
            <td><?php echo $row["FavColor"]; ?></td>
            <td><?php echo $row["FavPlace"]; ?></td>
            <td><?php echo $row["Nickname"]; ?></td>
            <td>
                <form method='POST' style="margin:0;">
                    <input type="submit" value="Edit" name="edit">
                    <input type="hidden" value="<?php echo $row["id"]; ?>" name="person_id">
                </form>
            </td>
            <td>
                <form method='POST' style="margin:0;">
                    <input type="submit" value="Delete" name="delete">
                    <input type="hidden" value="<?php echo $row["id"]; ?>" name="person_id">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <form method='POST'>
        <input type="hidden" value="<?php echo $dob; ?>" name="person_id">
        <h3>Name: <br><input type="text" name="name" value="<?php echo $fullname; ?>" required></h3>
        <h3>Date of Birth: <br><input type="date" name="dob" value="<?php echo $dob; ?>" required></h3>
        <h3>Favorite Color: <br><input type="text" name="fav_color" value="<?php echo $favColor; ?>" required></h3>
        <h3>Favorite Place To Visit: <br><input type="text" name="fav_place" value="<?php echo $favPlac; ?>" required></h3>
        <h3>Nickname: <br><input type="text" name="nickname" value="<?php echo $nicname; ?>" required></h3>
        
        <?php if (!$edit): ?>
            <input type="submit" value="Add Information" name="add">
        <?php else: ?>
            <input type="submit" value="Update Information" name="update">
        <?php endif; ?>
    </form>
</body>
</html>