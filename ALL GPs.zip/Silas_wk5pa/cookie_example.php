<?php
    $cookie_info = "No cookie info display...press a button";

    if (isset($_POST['test'])) {

        setcookie("test", "test", time() + 60, '/');
        
        $cookie_info = (count($_COOKIE) > 0)
            ? "Cookies are enabled" : "Cookies are disabled";
                }
else {
    $cookie_name = "clicks";

    if (isset($_POST['click_count'])) {

        $cookie_value = isset($_COOKIE[$cookie_name])
        ? $_COOKIE[$cookie_name] : 0;

        $cookie_value++;
        $cookie_info = "Number of clicks: " . $cookie_value;
        
        setcookie($cookie_name, $cookie_value, time() + 3600, "/");
    }
    else if (isset($_POST['delete'])) {
        setcookie($cookie_name, 0, time() - 3600, "/");
        $cookie_info = "Click cookie deleted";
    }

else if (isset($_COOKIE[$cookie_name])) {
    $cookie_value = $_COOKIE[$cookie_name];
    $cookie_info = "Number of click: " . $cookie_value;
}
}
?>
<html>
<body>
    <form method="POST">
        <p><?php echo $cookie_info; ?></p>
        <input type="submit" value="Test Cookies" name="test"/>
        <input type="submit" value="Count Clicks" name="click_count"/>
        <input type="submit" value="Delete Clicks" name="delete"/>
         </form>




</body>
</html>
