<?php
require_once('../controller/userinfo_controller.php');
$user_arr = get_users();
?>
<style>
table {
border-spacing: 5px;
}
table, th, td {
border: 1px solid black;
border-collapse: collapse;
}
th, td {
padding: 15px;
text-align: center;
}
th {
background-color:lightskyblue;
}
tr:nth-child(even) {
background-color:whitesmoke;
}
tr:nth-child(odd) {
background-color:lightgray;
}
</style>

<?php
require_once('../controller/userinfo_controller.php');
$user_arr = get_users();
?>

<html>
<head>
<title>Week4 PA - Jaboris Silas</title>
<link rel="stylesheet" href="styles.css">
</head>

<body>
<h2>Current Users:</h2>
<table>
<tr style="font-size:large;">
<th>Product #</th>
<th>Full Name</th>
<th>Type</th>

</tr>

<?php foreach($user_arr as $user):;?>
<tr>
<td><?php echo $user["ProductNo"];?></td>
<td><?php echo $user["Name"];?></td>
<td><?php echo $user["Type"];?></td>

</tr>
<?php endforeach;?>
</table>
<a href="find_user.php">Find a User</a> 
</body>
</html>