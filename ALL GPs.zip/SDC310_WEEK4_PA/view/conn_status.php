<?php
    require_once('../controller/connect_controller.php');
?>
<html>
    <head>
        <title>Week4 PA4.5 - JaBoris Silas</title>  
    </head>
    <body>
    <h1><?php echo get_conn_info(); ?></h1>
    </body>
</html>
  