<?php session_start(); ?>
<html>
    <head>
        <title>Week5 PA - JaBoris Silas</title>
    </head>

    <body>
        <h2>
            The BirthDay in the session is: <?php echo $_SESSION['user']; ?> 
        </h2>
        <br>
        <a href="session_expample.php">Back to Session Example Page</a>
    </body>
    </html>