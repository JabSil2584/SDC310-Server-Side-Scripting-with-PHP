<?php
// Start session to retrieve session variables
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Name Wk 5 Performance Assessment</title>
</head>
<body>
    <h2>The Name in the Cookie is: <?php echo isset($_COOKIE['user_name']) ? htmlspecialchars($_COOKIE['user_name']) : 'No Name Stored'; ?></h2>
    <h2>The Birthdate in the Session is: <?php echo isset($_SESSION['dob']) ? htmlspecialchars($_SESSION['dob']) : 'No Birthdate Stored'; ?></h2>
    <br>
    <a href="data_entry.php">Back to Data Entry Page</a>
</body>
</html>