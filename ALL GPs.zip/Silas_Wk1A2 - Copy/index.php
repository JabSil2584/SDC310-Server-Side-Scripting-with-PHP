<html>

<head>
    <title>Welcome to PHP!</title>
</head>

<body>
    <?php echo '<h1 style="text-align: center;">Welcome to PHP!</h1>'?>
    <?php echo '<h2 style="text-align: center;">My Name is JaBoris Silas</h2>' ?>
    <?php echo '<p style="text-align: center;">The Date is 05Sep2026</p>' ?>
    <?php echo '<p style="text-align: center;">The Time is 9:43pm</p>' ?>
    <?php echo '<p style="text-align: center;">The class is SDC310</p>' ?>
</body>
<?php echo '<p style="text-align: center;">My favorite color is black</p>' ?>
</html>