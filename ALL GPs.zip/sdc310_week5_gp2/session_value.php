<?php session_start(); ?>
<html>
    <head>
        <title>Week5 GP2 - JaBoris Silas</title>
    </head>

    <body>
        <h2>
            The Name in the session is: <?php echo $_SESSION['user']; ?> 
        </h2>
        <br>
        <a href="session_expample.php">Back to Session Example Page</a>
    </body>
    </html>