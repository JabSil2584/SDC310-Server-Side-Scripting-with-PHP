<?php
//Connect to Database
$hostname = "localhost";
$username = "ecpi_user";
$password = "Password1";
$dbname = "sdc310_wk3gp";
$conn = mysqli_connect($hostname, $username, $password, $dbname);

//Establish variables to support add/edit/delete

$fullName = "";
$doa = "";
$nicName = "";
$favPlac = 0;

//Variables to determine the type of operation
$add = false;
$edit = false;
$update = false;
$delete = false;


if (isset($_POST['user_no'])) {
   
    $add = isset($_POST['add']);
    $update = isset($_POST['update']);
    $edit = isset($_POST['edit']);
    $delete = isset($_POST['delete']);
}

if ($add) {
    //Need to add a new user
    $fullName = $_POST['fullname'];
    $doa = $_POST['dob'];
    $nicName = $_POST['nicName'];
    $favPlac = $_POST['fav_Plac'];

    $addQuery = "INSERT INTO 
        userinfo (fullName, dob, nicName, fav_Plac)
        VALUES ('$fullName', '$doa', '$nicName', '$favPlac')";
    mysqli_query($conn, $addQuery);

    //Clear the fields
    $userNo = -1;
    $fullName = "";
    $doa = "";
    $nicName = "";
    $favPlac = 0;
}
else if ($edit) {
    //Get the user information
    $selQuery = "SELECT * FROM userinfo WHERE UserNo = $userNo";
    $result = mysqli_query($conn, $selQuery);
    $userInfo = mysqli_fetch_assoc($result);

    //Fill in the values to allow for edit
    $fullName = $userInfo['fullName'];
    $doa = $userInfo['dob'];
    $nicName = $userInfo['nicName'];
    $favPlac = $userInfo['fav_Plac'];
}
else if ($update) {
    //Updated values submitted
    $fullName = $_POST['fullname'];
    $doa = $_POST['dob'];
    $nicName = $_POST['nicName'];
    $favPlac = $_POST['fav_Plac'];

    $updQuery = "UPDATE userinfo SET
        fullName = '$fullName', 
        nicName = '$nicName', fav_Plac = $favPlac 
        WHERE UserNo = $userNo";
    mysqli_query($conn, $updQuery);

    //Clear the fields
    $userNo = -1;
    $fullName = "";
    $doa = "";
    $nicName = "";
    $favPlac = 0;
}
else if ($delete) {
    //Need to delete the selected user
    $delQuery = "DELETE FROM userinfo WHERE UserNo = $userNo";
    mysqli_query($conn, $delQuery);
    $userNo = -1;
}

//Query for all users
$query = "SELECT * FROM userinfo";
$result = mysqli_query($conn, $query);
?>
<style>
    table {
        border-spacing: 5px;
    }
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    th, td {
        padding: 15px;
        text-align: center;
    }
    th {
        background-color: lightskyblue;
    }
    tr:nth-child(even) {
        background-color: whitesmoke;
    }
    tr:nth-child(odd) {
        background-color: lightgray;
    }
</style>
<html>
    <head>
        <title>Week3 PA - JaBoris Silas</title>
    </head>

    <body>
        <h2>Current Users:</h2>
        <table>
            <tr style="font-size:large;">
                <th>User #</th>
                <th>Full Name</th>
                <th>Birthday Date</th>
                <th>Favorite Place</th>
                <th>Favorite color</th>
                <th></th>
                <th></th>
            </tr>

<?php while($row = mysqli_fetch_array($result)):;?>
            <tr>
                <td><?php echo $row["fullName"]; ?></td>
                <td><?php echo $row["dob"]; ?></td>
                <td><?php echo $row["fav_Plac"]; ?></td>
                <td><?php echo $row["fav_color"]; ?></td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Edit" name="edit">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="user_no">
                    </form>
                </td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Delete" name="delete">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="user_no">
                    </form>
                </td>
            </tr>
<?php endwhile;?>
        </table>
        <form method='POST'>
            <input type="hidden" value="<?php echo $userNo; ?>" name="user_no">
            <h3>Enter your full name: <input type="text" name="fullname" 
                value="<?php echo $fullName; ?>"></h3>
            <h3>Enter your birth day: <input type="text" name="dob" 
                value="<?php echo $doa; ?>"></h3>
            <h3>Enter your Nick Name: <input type="text" name="nicName" 
                value="<?php echo $nicName; ?>"></h3>
            <h3>Enter your favorite Place to Visit: <input type="text" name="fav_Plac" 
                value="<?php echo $favPlac; ?>"></h3>
            <?php if (!$edit): ?>
                <input type="submit" value="Add User" name="add">
            <?php else: ?>
                <input type="submit" value="Update User" name="update">
            <?php endif; ?>
        </form>
    </body>
</html>