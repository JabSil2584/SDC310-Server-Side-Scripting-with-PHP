<html>

<head>
    <title>Hello SDC310 Cruel World!</title>
</head>

<body>
    <?php echo '<p>My Name is <b>JB Silas</b></p>'; ?>
    <?php echo '<p>It was run from the IDE</p>'; ?>
</body>

</html>