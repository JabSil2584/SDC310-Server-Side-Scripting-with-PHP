<?php
//Connect to Database
$hostname = "localhost";
$username = "ecpi_user";
$password = "Password1";
$dbname = "sdc310_midterm";
$conn = mysqli_connect($hostname, $username, $password, $dbname);

//Establish variables to support add/edit/delete
$addrNo = -1;
$firstName = "";
$lastName = "";
$street = "";
$city = "";
$state = "";
$zip = 0;

//Variables to determine the type of operation
$add = false;
$edit = false;
$update = false;
$delete = false;


if (isset($_POST['addr_no'])) {
    $addrNo = $_POST['addr_no'];
    $add = isset($_POST['add']);
    $update = isset($_POST['update']);
    $edit = isset($_POST['edit']);
    $delete = isset($_POST['delete']);
}

if ($add) {
    //Need to add a new user
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip_num'];

    $addQuery = "INSERT INTO 
        userinfo (FirstName, LastName, street, City, STate, ZipNum)
        VALUES ('$firstName', '$lastName', '$street', '$city', '$state', '$zip')";
    mysqli_query($conn, $addQuery);

    //Clear the fields
    $addrNo = -1;
    $firstName = "";
    $lastName = "";
    $street = "";
    $city = "";
    $state = "";
    $zip = 0;
}
else if ($edit) {
    //Get the user information
    $selQuery = "SELECT * FROM userinfo WHERE AddrNo = $addrNo";
    $result = mysqli_query($conn, $selQuery);
    $userInfo = mysqli_fetch_assoc($result);

    //Fill in the values to allow for edit
    $firstName = $userInfo['FirstName'];
    $lastName = $userInfo['LastName'];
    $street = $userInfo['STreet'];
    $city = $userInfo['City'];
    $state = $userInfo['STate'];
    $zip = $userInfo['ZipNum'];
}
else if ($update) {
    //Updated values submitted
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip_num'];

    $updQuery = "UPDATE userinfo SET
        FirstName = '$firstName', LastName = '$lastName', 
        STreet = '$street', City = '$city', STate = '$state', ZipNum = '$zip' 
        WHERE AddrNo = $addrNo";
    mysqli_query($conn, $updQuery);

    //Clear the fields
    $addrNo = -1;
    $firstName = "";
    $lastName = "";
    $street = "";
    $city = "";
    $state = "";
    $zip = 0;
}
else if ($delete) {
    //Need to delete the selected user
    $delQuery = "DELETE FROM userinfo WHERE AddrNo = $addrNo";
    mysqli_query($conn, $delQuery);
    $addrNo = -1;
}

//Query for all users
$query = "SELECT * FROM userinfo";
$result = mysqli_query($conn, $query);
?>
<style>
    table {
        border-spacing: 5px;
    }
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    th, td {
        padding: 15px;
        text-align: center;
    }
    th {
        background-color: lightskyblue;
    }
    tr:nth-child(even) {
        background-color: whitesmoke;
    }
    tr:nth-child(odd) {
        background-color: lightgray;
    }
</style>
<html>
    <head>
        <title>Week3 Midterm - JaBoris Silas</title>
    </head>

    <body>
        <h2>Current Users:</h2>
        <table>
            <tr style="font-size:large;">
                <th>Address #</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Street</th>
                <th>City</th>
                <th>State</th>
                <th>Zip</th>
                <th></th>
                <th></th>
            </tr>

<?php while($row = mysqli_fetch_array($result)):;?>
            <tr>
                <td><?php echo $row["UserNo"]; ?></td>
                <td><?php echo $row["FirstName"]; ?></td>
                <td><?php echo $row["LastName"]; ?></td>
                <td><?php echo $row["street"]; ?></td>
                <td><?php echo $row["City"]; ?></td>
                <td><?php echo $row["STreet"]; ?></td>
                <td><?php echo $row["ZipNum"]; ?></td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Edit" name="edit">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="addr_no">
                    </form>
                </td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Delete" name="delete">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="addr_no">
                    </form>
                </td>
            </tr>
<?php endwhile;?>
        </table>
        <form method='POST'>
            <input type="hidden" value="<?php echo $addrNo; ?>" name="addr_no">
            <h3>Enter your first name: <input type="text" name="fname" 
                value="<?php echo $firstName; ?>"></h3>
            <h3>Enter your last name: <input type="text" name="lname" 
                value="<?php echo $lastName; ?>"></h3>
            <h3>Enter your street address: <input type="text" name="street" 
                value="<?php echo $street; ?>"></h3>
             <h3>Enter your City: <input type="text" name="city" 
                value="<?php echo $city; ?>"></h3>
            <h3>Enter your State: <input type="text" name="state" 
                value="<?php echo $state; ?>"></h3>
            <h3>Enter your zip code: <input type="number" name="zip_num" 
                value="<?php echo $zip; ?>"></h3>
            <?php if (!$edit): ?>
                <input type="submit" value="Add User" name="add">
            <?php else: ?>
                <input type="submit" value="Update User" name="update">
            <?php endif; ?>
        </form>
    </body>
</html>