<html>

<head>
    <title>Week2 - JaBoris Silas Performance Assessment</title>
</head>

<body>
    <form method='POST'>
        <h3>Enter your full name: <input type="text" name="fname"></h3>
        <h3>Enter your Date of Birth: <input type="text" name="dob"></h3>
        <h3>Enter your Favorite place to visit: <input type="text" name="fav_place"></h3>
        <h3>Enter your favorite Color: <input type="text" name="fav_color"></h3>
        <h3>Enter your Nickname: <input type="text" name="nic_name"></h3>
        <input type="submit" value="Submit Values">
    </form>
<?php
    //Declare and clear variables for display
    $full_name = '';
    $date_birth = '';
    $fav_place = '';
    $fav_color = '';
    $nic_name = '';

    //Retrieve values from query string and store in a local variable
    //as long as the query string exists (which it does not on first
    //load of a page)
    if (isset($_POST['fname']))
        $full_name = $_POST['fname'];
        var_dump($full_name);
    if (isset($_POST['dob']))
        $date_birth = $_POST['dob'];
        var_dump($date_birth);
    if (isset($_POST['fav_place']))
        $fav_place = $_POST['fav_place'];
        var_dump($fav_place);
    if (isset($_POST['fav_color']))
        $fav_color = $_POST['fav_color'];
        var_dump($fav_color);
    if (isset($_POST['nic_name']))
        $nic_name = $_POST['nic_name'];
        var_dump($nic_name);

    //Display the values entered as long as there is a value there
    if (strlen($full_name) > 0 || strlen($full_name) > 0)
        print "<h3> The name you entered is: $full_name </h3>";
    if (strlen($date_birth) > 0)
        print "<h3> Your birthday is: $date_birth </h3>";
    if (strlen($fav_color) > 0)
        print "<h3> Your favorite color is: $fav_color </h3>";
    if (strlen($nic_name) > 0)
        print "<h3> Your Nick name is: $nic_name </h3>";
    if (strlen($fav_place) > 0)
        if (is_string($fav_place))
            print "<h3> You said your favorite place is: $fav_place </h3>";
        else
            print "<h3> That's not a place! </h3>";
?>
</body>

</html>
