<html>
    <head>
        <title>Week3 PA - JaBoris Silas (MVC)</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <body>
        <h2>Current Users:</h2>
        <table>
            <tr style="font-size:large;">
                <th>NickName</th>
                <th>Full Name</th>
                <th>Date of Birth</th>
                <th>Favorite Color</th>
                <th>Favorite Place to Visit</th>
                <th></th>
                <th></th>
            </tr>

<?php while($row = mysqli_fetch_array($result)):;?>
            <tr>
                <td><?php echo $row["UserNo"]; ?></td>
                <td><?php echo $row["FirstName"]; ?></td>
                <td><?php echo $row["LastName"]; ?></td>
                <td><?php echo $row["EMail"]; ?></td>
                <td><?php echo $row["FavoriteNum"]; ?></td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Edit" name="edit">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="user_no">
                    </form>
                </td>
                <td>
                    <form method='POST'>
                        <input type="submit" value="Delete" name="delete">
                        <input type="hidden" 
                            value="<?php echo $row["UserNo"]; ?>" 
                            name="user_no">
                    </form>
                </td>
            </tr>
<?php endwhile;?>
        </table>
        
        <form method='POST'>
            <input type="hidden" value="<?php echo $userNo; ?>" name="user_no">
            <h3>Enter your full name: <input type="text" name="fname" 
                value="<?php echo $firstName; ?>"></h3>
            <h3>Enter your Date of birth: <input type="text" name="lname" 
                value="<?php echo $lastName; ?>"></h3>
            <h3>Enter your favorite color: <input type="text" name="email" 
                value="<?php echo $email; ?>"></h3>
            <h3>Enter your nick name: <input type="text" name="UserNo" 
                value="<?php echo $userNo; ?>"></h3>
            <h3>Enter your favorite place to visit: <input type="text" name="fav_num" 
                value="<?php echo $favNum; ?>"></h3>
            
            <?php if (!$edit): ?>
                <input type="submit" value="Add User" name="add">
            <?php else: ?>
                <input type="submit" value="Update User" name="update">
            <?php endif; ?>
        </form>
    </body>
</html>