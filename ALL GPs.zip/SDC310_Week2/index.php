<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connect to Database - Lecture</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
<header class="container"> 
    This the Header 
    <?php
    ?> 
    </header>
    <div> <?php
    include('.vscode/header_for_template.php') 
    ?>
     </div> 
    <div>
        <h2 class="text-center">This is the Homepage</h2>
        <p>I got nothing to say <br />jbjabjjdvbk<br />jjgbfb</p>
        <p>list list ls list</p>
    </div>
</body>
</html>