<?php
//Connect to Database
$hostname = "localhost";
$username = "ecpi_user";
$password = "Password1";
$dbname = "sdc310_midterm";
$conn = mysqli_connect($hostname, $username, $password, $dbname);

//Establish variables to support add/edit/delete
$addrNo = -1;
$firstName = "";
$lastName = "";
$street = "";
$city = "";
$state = "";
$zip = "";

//Variables to determine the type of operation
$add = false;
$edit = false;
$update = false;
$delete = false;

if (isset($_POST['addr_no'])) {
$addrNo = $_POST['addr_no'];
$add = isset($_POST['add']);
$update = isset($_POST['update']);
$edit = isset($_POST['edit']);
$delete = isset($_POST['delete']);
}

if ($add) {
//Need to add a new address record
$firstName = $_POST['fname'];
$lastName = $_POST['lname'];
$street = $_POST['street'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip_num'];

$addQuery = "INSERT INTO addresses (First, Last, STreet, City, State, Zip)
VALUES ('$firstName', '$lastName', '$street', '$city', '$state', '$zip')";
mysqli_query($conn, $addQuery);

//Clear the fields
$addrNo = -1;
$firstName = "";
$lastName = "";
$street = "";
$city = "";
$state = "";
$zip = "";
}
else if ($edit) {
//Get the address information for editing (matched to database column AddrNo)[cite: 9]
$selQuery = "SELECT * FROM addresses WHERE AddrNo = $addrNo";
$result = mysqli_query($conn, $selQuery);
$addressInfo = mysqli_fetch_assoc($result);

//Fill in the values to allow for edit (matched to database column STreet)[cite: 9]
$firstName = $addressInfo['First'];
$lastName = $addressInfo['Last'];
$street = $addressInfo['STreet'];
$city = $addressInfo['City'];
$state = $addressInfo['State'];
$zip = $addressInfo['Zip'];
}
else if ($update) {
//Updated values submitted (matched to database columns AddrNo and STreet)[cite: 9]
$firstName = $_POST['fname'];
$lastName = $_POST['lname'];
$street = $_POST['street'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip_num'];

$updQuery = "UPDATE addresses SET
First = '$firstName', Last = '$lastName',
STreet = '$street', City = '$city', State = '$state', Zip = '$zip'
WHERE AddrNo = $addrNo";
mysqli_query($conn, $updQuery);

//Clear the fields
$addrNo = -1;
$firstName = "";
$lastName = "";
$street = "";
$city = "";
$state = "";
$zip = "";
}
else if ($delete) {
//Need to delete the selected address (matched to database column AddrNo)[cite: 9]
$delQuery = "DELETE FROM addresses WHERE AddrNo = $addrNo";
mysqli_query($conn, $delQuery);
$addrNo = -1;
}

//Query for all addresses
$query = "SELECT * FROM addresses";
$result = mysqli_query($conn, $query);
?>
<style>
table {
border-spacing: 5px;
}
table, th, td {
border: 1px solid black;
border-collapse: collapse;
}
th, td {
padding: 15px;
text-align: center;
}
th {
background-color: lightskyblue;
}
tr:nth-child(even) {
background-color: whitesmoke;
}
tr:nth-child(odd) {
background-color: lightgray;
}
</style>
<html>
<head>
<title>JaBoris Silas Midterm</title>
</head>

<body>
<h2>Current Addresses:</h2>
<table>
<tr style="font-size:large;">
<th>Address #</th>
<th>First Name</th>
<th>Last Name</th>
<th>Street Address</th>
<th>City</th>
<th>State</th>
<th>Zip Code</th>
<th></th>
<th></th>
</tr>

<?php while($row = mysqli_fetch_array($result)):;?>
<tr>
<td><?php echo $row["AddrNo"]; ?></td>
<td><?php echo $row["First"]; ?></td>
<td><?php echo $row["Last"]; ?></td>
<td><?php echo $row["STreet"]; ?></td>
<td><?php echo $row["City"]; ?></td>
<td><?php echo $row["State"]; ?></td>
<td><?php echo $row["Zip"]; ?></td>
<td>
<form method='POST'>
<input type="submit" value="Edit" name="edit">
<input type="hidden"
value="<?php echo $row["AddrNo"]; ?>"
name="addr_no">
</form>
</td>
<td>
<form method='POST'>
<input type="submit" value="Delete" name="delete">
<input type="hidden"
value="<?php echo $row["AddrNo"]; ?>"
name="addr_no">
</form>
</td>
</tr>
<?php endwhile;?>
</table>
<form method='POST'>
<input type="hidden" value="<?php echo $addrNo; ?>" name="addr_no">
<h3>Enter your first name: <input type="text" name="fname"
value="<?php echo $firstName; ?>"></h3>
<h3>Enter your last name: <input type="text" name="lname"
value="<?php echo $lastName; ?>"></h3>
<h3>Enter your street address: <input type="text" name="street"
value="<?php echo $street; ?>"></h3>
<h3>Enter your city: <input type="text" name="city"
value="<?php echo $city; ?>"></h3>
<h3>Enter your state: <input type="text" name="state"
value="<?php echo $state; ?>"></h3>
<h3>Enter your zip code: <input type="text" name="zip_num"
value="<?php echo $zip; ?>"></h3>
<?php if (!$edit): ?>
<input type="submit" value="Add User" name="add">
<?php else: ?>
<input type="submit" value="Update User" name="update">
<?php endif; ?>
</form>
</body>
</html>